
import React, { createContext, useContext, useState, ReactNode } from 'react';

interface BookingContextType {
  user: User | null;
  login: (username: string, password: string) => void;
  logout: () => void;
  register: (userDetails: Omit<User, 'id'>) => void;
  booking: BookingDetails | null;
  setBooking: (booking: BookingDetails) => void;
  confirmBooking: () => void;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  title: string;
  affiliation: string;
  email: string;
  username: string;
  phone: string;
}

export interface BookingDetails {
  exhibitionType?: string;
  session?: "Morning" | "Afternoon";
  seat?: string;
  price?: string;
  time?: string;
  seatSection?: string;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const BookingProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [booking, setBookingState] = useState<BookingDetails | null>(null);

  const login = (username: string, password: string) => {
    // Mock login - in a real app, this would verify with a backend
    setUser({
      id: '1',
      firstName: 'Mayanja',
      lastName: 'Emmanuel',
      title: 'Mr',
      affiliation: 'Student',
      email: 'mayanja@example.com',
      username,
      phone: '+256 700 123 456',
    });
  };

  const logout = () => {
    setUser(null);
    setBookingState(null);
  };

  const register = (userDetails: Omit<User, 'id'>) => {
    // Mock registration - in a real app, this would send to a backend
    setUser({ ...userDetails, id: Math.random().toString() });
  };

  const setBooking = (booking: BookingDetails) => {
    setBookingState(booking);
  };

  const confirmBooking = () => {
    // In a real app, this would send the booking to a backend
    console.log("Booking confirmed:", booking);
  };

  return (
    <BookingContext.Provider value={{
      user,
      login,
      logout,
      register,
      booking,
      setBooking,
      confirmBooking,
    }}>
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (context === undefined) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};
