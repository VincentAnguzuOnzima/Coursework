
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBooking } from '@/contexts/BookingContext';

const SeatSelection = () => {
  const [selectedTime, setSelectedTime] = useState<string>("AM");
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  
  const navigate = useNavigate();
  const { booking, setBooking } = useBooking();

  const handleBack = () => {
    navigate('/exhibitions');
  };

  const handleNext = () => {
    if (selectedSeat && selectedSection && selectedTime) {
      setBooking({
        ...booking!,
        seat: selectedSeat,
        time: selectedTime,
        seatSection: selectedSection
      });
      navigate('/booking-summary');
    }
  };

  // Generate rows of seats
  const renderSeatRow = (prefix: string, count: number) => {
    return Array.from({ length: count }, (_, i) => {
      const seatLabel = `${prefix}${i + 1}`;
      return (
        <button
          key={seatLabel}
          className={`w-16 h-12 bg-brand-Blue border-2 border-brand-blue rounded-md font-bold flex items-center justify-between px-3
            ${selectedSeat === seatLabel && selectedSection === prefix ? 'bg-brand-blue text-white' : ''}`}
          onClick={() => {
            setSelectedSeat(seatLabel);
            setSelectedSection(prefix);
          }}
        >
          {seatLabel.charAt(0)}
          <span className="text-xs">▼</span>
        </button>
      );
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-8">
      <div className="w-full max-w-4xl">
        <div className="flex justify-between items-center mb-16">
          <div className="text-2xl font-bold text-brand-blue">Select Time:</div>
          <select
            value={selectedTime}
            onChange={(e) => setSelectedTime(e.target.value)}
            className="w-64 p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none appearance-none"
          >
            <option value="AM">AM</option>
            <option value="PM">PM</option>
          </select>
        </div>
        
        <div className="mb-8">
          <div className="text-3xl font-bold text-brand-blue mb-4">Front:</div>
          <div className="grid grid-cols-6 gap-2">{renderSeatRow("A", 6)}</div>
        </div>
        
        <div className="mb-8">
          <div className="text-3xl font-bold text-brand-blue mb-4">Middle:</div>
          <div className="grid grid-cols-6 gap-4">{renderSeatRow("G", 6)}</div>
        </div>
        
        <div className="mb-8">
          <div className="text-3xl font-bold text-brand-blue mb-4">Balcony:</div>
          <div className="grid grid-cols-6 gap-4">{renderSeatRow("AA", 6)}</div>
        </div>
        
        <div className="mb-16">
          <div className="text-3xl font-bold text-brand-blue mb-4">VIP:</div>
          <div className="grid grid-cols-6 gap-4">{renderSeatRow("X", 1)}</div>
        </div>
        
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            className="px-12 py-3 bg-pink-100 text-brand-burgundy rounded-md font-bold text-xl"
          >
            Back
          </button>
          
          <button
            onClick={handleNext}
            className="px-12 py-3 bg-brand-burgundy text-white rounded-md font-bold text-xl"
            disabled={!selectedSeat || !selectedSection}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default SeatSelection;
