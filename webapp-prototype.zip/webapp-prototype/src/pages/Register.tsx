
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Phone, Eye, EyeOff } from 'lucide-react';
import { useBooking } from '@/contexts/BookingContext';

const Register = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    title: '',
    affiliation: '',
    email: '',
    username: '',
    phone: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const { register } = useBooking();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    register(formData);
    navigate('/exhibitions');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl md:text-5xl font-bold text-brand-burgundy mb-12">
        REGISTER
      </h1>
      
      <div className="w-full max-w-3xl">
        <form onSubmit={handleRegister} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="relative">
            <input
              type="text"
              name="firstName"
              placeholder="First Name"
              value={formData.firstName}
              onChange={handleChange}
              className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none"
              required
            />
          </div>
          
          <div className="relative">
            <input
              type="text"
              name="lastName"
              placeholder="Last Name"
              value={formData.lastName}
              onChange={handleChange}
              className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none"
              required
            />
          </div>
          
          <div className="relative">
            <select
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none appearance-none"
              required
            >
              <option value="" disabled>Title</option>
              <option value="Mr">Mr</option>
              <option value="Mrs">Mrs</option>
              <option value="Ms">Ms</option>
              <option value="Dr">Dr</option>
              <option value="Prof">Prof</option>
            </select>
          </div>
          
          <div className="relative">
            <select
              name="affiliation"
              value={formData.affiliation}
              onChange={handleChange}
              className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none appearance-none"
              required
            >
              <option value="" disabled>Affiliation</option>
              <option value="Student">Student</option>
              <option value="Faculty">Faculty</option>
              <option value="Staff">Staff</option>
              <option value="Guest">Guest</option>
            </select>
          </div>
          
          <div className="relative">
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none"
              required
            />
          </div>
          
          <div className="relative">
            <input
              type="text"
              name="username"
              placeholder="Username"
              value={formData.username}
              onChange={handleChange}
              className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none"
              required
            />
          </div>
          
          <div className="relative">
            <div className="flex items-center bg-brand-lightBlue border-2 border-brand-blue rounded-md">
              <Phone className="ml-3 text-gray-400" size={20} />
              <input
                type="tel"
                name="phone"
                placeholder="Phone Number"
                value={formData.phone}
                onChange={handleChange}
                className="w-full p-4 bg-transparent focus:outline-none"
                required
              />
            </div>
          </div>
          
          <div className="relative">
            <div className="flex items-center bg-brand-lightBlue border-2 border-brand-blue rounded-md">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
                className="w-full p-4 bg-transparent focus:outline-none"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="mr-3 text-gray-400"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>
          
          <div className="md:col-span-2 mt-6">
            <button
              type="submit"
              className="w-full p-4 bg-brand-burgundy text-white rounded-md font-bold uppercase"
            >
              REGISTER
            </button>
          </div>
        </form>
        
        <div className="mt-8 text-center">
          <p className="inline mr-2">Already have an account?</p>
          <Link to="/login" className="text-brand-blue font-semibold">
            Login
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
