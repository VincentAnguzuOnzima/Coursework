
import { useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { useBooking } from '@/contexts/BookingContext';

const TicketConfirmation = () => {
  const navigate = useNavigate();
  const { logout } = useBooking();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleBookAgain = () => {
    navigate('/exhibitions');
  };

  const handlePrintTicket = () => {
    window.print();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-lg flex flex-col items-center">
        <h1 className="text-5xl font-bold text-brand-burgundy mb-24">
          Ticket Confirmed
        </h1>
        
        <button
          onClick={handlePrintTicket}
          className="text-4xl text-gray-600 mb-24 border-b-2 border-gray-600"
        >
          Print Ticket
        </button>
        
        <div className="flex justify-between w-full mt-16">
          <button
            onClick={handleLogout}
            className="px-8 py-4 bg-pink-100 text-brand-burgundy rounded-md font-bold text-xl flex items-center"
          >
            <LogOut className="mr-2" /> Log Out
          </button>
          
          <button
            onClick={handleBookAgain}
            className="px-8 py-4 bg-brand-burgundy text-white rounded-md font-bold text-xl"
          >
            Book Again
          </button>
        </div>
      </div>
    </div>
  );
};

export default TicketConfirmation;
