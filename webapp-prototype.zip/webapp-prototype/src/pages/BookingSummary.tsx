
import { useNavigate } from 'react-router-dom';
import { useBooking } from '@/contexts/BookingContext';

const BookingSummary = () => {
  const navigate = useNavigate();
  const { user, booking, confirmBooking } = useBooking();

  const handleBack = () => {
    navigate('/seat-selection');
  };

  const handleConfirm = () => {
    confirmBooking();
    navigate('/ticket-confirmation');
  };

  if (!user || !booking) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-2xl">
        <div className="bg-pink-50 border-2 border-brand-burgundy rounded-lg p-8 mb-16">
          <div className="space-y-4">
            <div className="flex">
              <h2 className="text-3xl font-bold text-brand-blue">Guest Name: </h2>
              <p className="text-3xl ml-2">{`${user.firstName} ${user.lastName}`}</p>
            </div>
            
            <div className="flex">
              <h2 className="text-3xl font-bold text-brand-blue">Session: </h2>
              <p className="text-3xl ml-2">{booking.session}</p>
            </div>
            
            <div className="flex">
              <h2 className="text-3xl font-bold text-brand-blue">Seat: </h2>
              <p className="text-3xl ml-2">{booking.seat}</p>
            </div>
            
            <div className="flex">
              <h2 className="text-3xl font-bold text-brand-blue">Price: </h2>
              <p className="text-3xl ml-2">{booking.price}</p>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            className="px-12 py-3 bg-pink-100 text-brand-burgundy rounded-md font-bold text-xl"
          >
            Back
          </button>
          
          <button
            onClick={handleConfirm}
            className="px-12 py-3 bg-brand-burgundy text-white rounded-md font-bold text-xl"
          >
            Confirm Booking
          </button>
        </div>
      </div>
    </div>
  );
};

export default BookingSummary;
