
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBooking } from '@/contexts/BookingContext';

const Exhibitions = () => {
  const [selectedSession, setSelectedSession] = useState<"Morning" | "Afternoon" | null>(null);
  const { setBooking } = useBooking();
  const navigate = useNavigate();

  const handleNext = () => {
    if (selectedSession) {
      // Mock data for demonstration
      setBooking({
        exhibitionType: "Robotics",
        session: selectedSession,
        seat: "A1",
        price: "UGX 150,000"
      });
      
      navigate('/seat-selection');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl md:text-6xl font-bold text-brand-burgundy mb-16">
        Exhibition Gathering
      </h1>
      
      <div className="w-full max-w-2xl">
        <div className="flex flex-col md:flex-row items-center justify-center gap-16 mb-16">
          <div className="flex items-center">
            <div 
              className={`w-8 h-8 rounded-full border-2 border-brand-blue flex items-center justify-center cursor-pointer ${selectedSession === 'Morning' ? 'bg-brand-blue' : 'bg-white'}`}
              onClick={() => setSelectedSession('Morning')}
            >
              {selectedSession === 'Morning' && <div className="w-4 h-4 rounded-full bg-white"></div>}
            </div>
            <span className="ml-4 text-3xl font-bold text-brand-blue">Morning</span>
          </div>
          
          <div className="flex items-center">
            <div 
              className={`w-8 h-8 rounded-full border-2 border-brand-blue flex items-center justify-center cursor-pointer ${selectedSession === 'Afternoon' ? 'bg-brand-blue' : 'bg-white'}`}
              onClick={() => setSelectedSession('Afternoon')}
            >
              {selectedSession === 'Afternoon' && <div className="w-4 h-4 rounded-full bg-white"></div>}
            </div>
            <span className="ml-4 text-3xl font-bold text-brand-blue">Afternoon</span>
          </div>
        </div>
        
        <div className="w-full max-w-xl mx-auto">
          <table className="w-full border-collapse border-2 border-brand-blue">
            <tbody>
              <tr>
                <td className="border-2 border-brand-blue p-4 text-2xl font-bold text-brand-blue">
                  Robotics
                </td>
                <td className="border-2 border-brand-blue p-4 text-2xl font-bold text-brand-blue">
                  Type
                </td>
              </tr>
              <tr>
                <td className="border-2 border-brand-blue p-4 text-2xl font-bold text-brand-blue">
                  Seat A1
                </td>
                <td className="border-2 border-brand-blue p-4 text-2xl font-bold text-brand-blue">
                  Seat
                </td>
              </tr>
              <tr>
                <td className="border-2 border-brand-blue p-4 text-2xl font-bold text-brand-blue">
                  UGX 150,000
                </td>
                <td className="border-2 border-brand-blue p-4 text-2xl font-bold text-brand-blue">
                  Price
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div className="flex justify-end mt-12">
          <button
            onClick={handleNext}
            className="px-12 py-3 bg-brand-burgundy text-white rounded-md font-bold text-xl"
            disabled={!selectedSession}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default Exhibitions;
