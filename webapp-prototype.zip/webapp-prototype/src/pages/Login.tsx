
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import { useBooking } from '@/contexts/BookingContext';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const { login } = useBooking();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(username, password);
    navigate('/exhibitions');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl md:text-5xl text-center font-bold text-brand-burgundy mb-12">
        VICTORIA UNIVERSITY EXHIBITION
      </h1>
      
      <div className="w-full max-w-2xl flex flex-col md:flex-row items-center gap-8">
        <div className="w-full md:w-2/3">
          <h2 className="text-3xl font-bold text-brand-blue mb-8 text-center">LOGIN</h2>
          
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="relative">
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-4 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none"
                required
              />
            </div>
            
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-4 pr-10 rounded-md bg-brand-lightBlue border-2 border-brand-blue focus:outline-none"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
            
            <button
              type="submit"
              className="w-full p-4 bg-brand-burgundy text-white rounded-md font-bold uppercase"
            >
              LOGIN
            </button>
          </form>
          
          <div className="mt-6 flex justify-between items-center">
            <p>Don't have an account?</p>
            <Link to="/register" className="text-brand-blue font-semibold">
              Register
            </Link>
          </div>
        </div>
        
        <div className="hidden md:block">
          <img 
            src="https://pbs.twimg.com/profile_images/1380124346543435785/lPjnOIfz_400x400.jpg" 
            alt="Victoria University Logo"
            className="w-70 h-auto backdrop-blur-sm"
          />
        </div>
      </div>
    </div>
  );
};

export default Login;
